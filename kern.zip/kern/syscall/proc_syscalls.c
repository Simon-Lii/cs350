#include "opt-A2.h"
#include "opt-A3.h"
#include <types.h>
#include <kern/errno.h>
#include <kern/unistd.h>
#include <kern/wait.h>
#include <lib.h>
#include <syscall.h>
#include <current.h>
#include <proc.h>
#include <thread.h>
#include <addrspace.h>
#include <copyinout.h>

#ifdef OPT_A2
#include <clock.h>
#include <mips/trapframe.h>
#endif /* OPT_A2 */

#ifdef OPT_A2
#include "test.h"
#include <vfs.h>
#include <kern/fcntl.h>
#include <limits.h>
#endif /* OPT_A3 */

  /* this implementation of sys__exit does not do anything with the exit code */
  /* this needs to be fixed to get exit() and waitpid() working properly */

void sys__exit(int exitcode) {

  struct addrspace *as;
  struct proc *p = curproc;
  /* for now, just include this to keep the compiler from complaining about
     an unused variable */
  (void)exitcode;

  DEBUG(DB_SYSCALL,"Syscall: _exit(%d)\n",exitcode);

  KASSERT(curproc->p_addrspace != NULL);
  as_deactivate();
  /*
   * clear p_addrspace before calling as_destroy. Otherwise if
   * as_destroy sleeps (which is quite possible) when we
   * come back we'll be calling as_activate on a
   * half-destroyed address space. This tends to be
   * messily fatal.
   */
  as = curproc_setas(NULL);
  as_destroy(as);

#ifdef OPT_A2
  while (array_num(curproc->p_children) > 0) {
    struct proc *temp_child;
    temp_child = array_get(curproc->p_children, 0);
    array_remove(curproc->p_children, 0);

    spinlock_acquire(&temp_child->p_lock);

    if (temp_child->p_exitstatus == 1) {
      spinlock_release(&temp_child->p_lock);
      proc_destroy(temp_child);
    } else {
      temp_child->p_parent = NULL;
      spinlock_release(&temp_child->p_lock);
    }
  }
#endif /* OPT_A2 */

  /* detach this thread from its process */
  /* note: curproc cannot be used after this call */
  proc_remthread(curthread);

  /* if this is the last user process in the system, proc_destroy()
     will wake up the kernel menu thread */
#ifdef OPT_A2
  spinlock_acquire(&p->p_lock);

  if (p->p_parent && p->p_parent->p_exitstatus == 0) {
    p->p_exitstatus = 1;
    p->p_exitcode = exitcode;
    spinlock_release(&p->p_lock);
  } else {
    spinlock_release(&p->p_lock);
    proc_destroy(p);
  }

#endif /* OPT_A2 */
  
  thread_exit();
  /* thread_exit() does not return, so we should never get here */
  panic("return from thread_exit in sys_exit\n");
}


/* stub handler for getpid() system call                */
int
sys_getpid(pid_t *retval)
{
  /* for now, this is just a stub that always returns a PID of 1 */
  /* you need to fix this to make it work properly */
  #ifdef OPT_A2
  *retval = curproc->p_pid;
  #endif /* OPT_A2 */
  return(0);
}

/* stub handler for waitpid() system call                */

int
sys_waitpid(pid_t pid,
	    userptr_t status,
	    int options,
	    pid_t *retval)
{
  int exitstatus;
  int result;

  /* this is just a stub implementation that always reports an
     exit status of 0, regardless of the actual exit status of
     the specified process.   
     In fact, this will return 0 even if the specified process
     is still running, and even if it never existed in the first place.

     Fix this!
  */

#ifdef OPT_A2

  struct proc *temp_child = NULL;
  for (unsigned i = 0; i < array_num(curproc->p_children); i++) {
    temp_child = array_get(curproc->p_children, i);
    if (temp_child->p_pid == pid) {
      array_remove(curproc->p_children, i);
      break;
    }
  }

  if (temp_child == NULL) {
    // child not found
    return -1;
  }

  spinlock_acquire(&temp_child->p_lock);
  while (!temp_child->p_exitstatus) {
    spinlock_release(&temp_child->p_lock);
    clocksleep (1);
    spinlock_acquire(&temp_child->p_lock);
  }
  spinlock_release(&temp_child->p_lock);

  exitstatus = _MKWAIT_EXIT(temp_child->p_exitcode);

  proc_destroy(temp_child);

  if (options != 0) {
    return(EINVAL);
  }
  /* for now, just pretend the exitstatus is 0 */

#endif /* OPT_A2 */
  result = copyout((void *)&exitstatus,status,sizeof(int));
  if (result) {
    return(result);
  }
  *retval = pid;
  return (0);
}

#ifdef OPT_A2

int
sys_fork(pid_t *retval, struct trapframe *tf) {
  struct proc *child_proc = proc_create_runprogram("child");

  child_proc->p_parent = curproc; // set curproc as parent to child proc

  array_add(curproc->p_children, child_proc, NULL);

  as_copy(curproc_getas(), &child_proc->p_addrspace);

  struct trapframe *trapframe_for_child;
  trapframe_for_child = kmalloc(sizeof(struct trapframe)); // must FREE?
  memcpy(trapframe_for_child, tf, sizeof(struct trapframe)); // copy content of tf into tf_for_child

  thread_fork("child_thread", 
              child_proc, 
              enter_forked_process,
              (void*) trapframe_for_child,
              0);

  *retval = child_proc->p_pid;
  
  clocksleep(1);
  return 0;
}

#endif /* OPT_A2 */

#ifdef OPT_A3

char** args_alloc(int nargs, char** argv) {
  (void) argv;
  char **args = kmalloc(sizeof(char *) * PATH_MAX); 
  for (int i = 0; i < PATH_MAX; i++) {
    if ((i == nargs && nargs <= PATH_MAX ) || i == PATH_MAX) {
      args[i] = NULL;
      break;
    }
    // int len = (strlen(argv[i]) + 1);
    args[i] = kmalloc(sizeof(char) * ARG_MAX);
  }
  return args;
}

int argscopy_in(int nargs, char** args, char** argv) {
  int total_num_of_str = 0;

  for (int i = 0; i < nargs; i++) {
    int len = strlen(argv[i]) + 1;
    int result = copyinstr((userptr_t) argv[i], args[i], len, NULL);
    if (result) return result;
    total_num_of_str++;
  }

  return total_num_of_str;
}

void args_free(int nargs, char **args) {
  for (int i = 0; i < nargs; i++) {
    kfree(args[i]);
  }

  kfree(args);
}

int sys_execv(char *progname, char **argv) {
  
  // Easy way to count number of args, since argv
  // is NULL terminated
  int nargs = 0;
  while (argv[nargs] != NULL)
  {
    nargs++; 
  }
  
  char **args = args_alloc(nargs, argv);

  nargs = 0;
  while (args[nargs] != NULL)
  {
    nargs++; 
  }

  argscopy_in(nargs, args, argv);

  struct addrspace *oldadress = curproc_getas();

  as_destroy(oldadress);

  struct addrspace *as;
	struct vnode *v;
	vaddr_t entrypoint, stackptr;
	int result;

	/* Open the file. */
	result = vfs_open(progname, O_RDONLY, 0, &v);
	if (result) {
		return result;
	}

	/* We should be a new process. */
	//KASSERT(curproc_getas() == NULL);

	/* Create a new address space. */
	as = as_create();
	if (as ==NULL) {
		vfs_close(v);
		return ENOMEM;
	}

	/* Switch to it and activate it. */
	curproc_setas(as);
	as_activate();

	/* Load the executable. */
	result = load_elf(v, &entrypoint);
	if (result) {
		/* p_addrspace will go away when curproc is destroyed */
		vfs_close(v);
		return result;
	}

	/* Done with the file now. */
	vfs_close(v);

	/* Define the user stack in the address space */
	result = as_define_stack(as, &stackptr);
	if (result) {
		/* p_addrspace will go away when curproc is destroyed */
		return result;
	}

	// Leave one extra space for NULL terminated array
	vaddr_t* argv_user = kmalloc((nargs + 1) * sizeof(vaddr_t));

	// The last item is NULL terminated
	argv_user[nargs] = (vaddr_t) NULL;

	// Since we are copying into a stack, we want to start from the TOP
	// of the args list
	for (int i = nargs - 1; i >= 0; i--) {
		// Pass stackptr by reference
		argv_user[i] = argcopy_out(&stackptr, args[i]);
	}

	// Debugged this for literally 4 hours
	// We want to copyout the null terminated char first...
	for (int i = nargs; i >= 0; i--) {
		stackptr = stackptr - ROUNDUP(sizeof(vaddr_t), 4);
		result = copyout((void *) &argv_user[i], (userptr_t) stackptr, sizeof(vaddr_t));
		if (result) return result;
	}

	/* Warp to user mode. */
	enter_new_process(nargs , (userptr_t) stackptr, stackptr, entrypoint);

	// Freeing :)
	kfree(argv_user);

  args_free(nargs, args);

	// as_destroy(as);
	/* enter_new_process does not return. */
	panic("enter_new_process returned\n");
	return EINVAL;
}

#endif /* OPT_A3 */
