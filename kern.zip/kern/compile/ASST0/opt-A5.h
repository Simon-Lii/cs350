/* Automatically generated; do not edit */
#ifndef _OPT_A5_H_
#define _OPT_A5_H_
#define OPT_A5 0
#endif /* _OPT_A5_H_ */
