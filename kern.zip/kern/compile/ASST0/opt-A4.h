/* Automatically generated; do not edit */
#ifndef _OPT_A4_H_
#define _OPT_A4_H_
#define OPT_A4 0
#endif /* _OPT_A4_H_ */
